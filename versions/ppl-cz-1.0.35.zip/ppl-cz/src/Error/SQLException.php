<?php
namespace PPLCZ\Error;

class SQLException extends \Exception
{

}