<?php

namespace PPLCZ\Front\Components;

class Stripe
{


    public static function stripe_express_fields($params)
    {
        if ($params && isset($params['checkout']))
            $params['checkout']['needs_payer_phone'] = true;
        return $params;
    }

    public static $isStripeShippingRequest = false;

    public static function  is_stripe_shipping_request($shipping_address)
    {
        self::$isStripeShippingRequest = true;
        return $shipping_address;
    }

    public static function pplcz_stripe_payment()
    {
        self::$isStripeShippingRequest = true;
    }

    public static function register()
    {
        add_action('pplcz_payment_stripe', [self::class, 'pplcz_stripe_payment']);
        add_filter('wc_stripe_express_checkout_params',[self::class, 'stripe_express_fields']);
        add_filter('wc_stripe_payment_request_shipping_posted_values', [self::class, 'is_stripe_shipping_request']);
    }

}


