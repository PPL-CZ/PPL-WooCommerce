<?php

namespace PPLCZ\Admin\Product;

defined("WPINC") or die();

use PPLCZ\Admin\Assets\JsTemplate;
use PPLCZ\Model\Model\PackageSizeModel;
use PPLCZ\Model\Model\ProductModel;
use PPLCZ\Entity\ProductEntity;
use PPLCZ\Serializer;
use PPLCZ\Model\Model\ShipmentMethodModel;
use PPLCZ\Setting\MethodSetting;
use PPLCZ\ShipmentMethod;

class Tab {

    /**
     * @param array $tabs
     * @return array
     */
    public static function Tabs($tabs)
    {
        $tabs["pplcz_shipping_tab"] = [
            "label" => "PPL",
            "target" => "pplcz_tab_overlay",
            "class" => [ 'hide_if_virtual', 'hide_if_downloadable'  ]
        ];

        return $tabs;
    }

    public static function get_shipping()
    {
        $output = [];
        foreach (MethodSetting::getMethods() as $v) {
            $shipmentMethodModel = pplcz_normalize($v);
            $output[] = $shipmentMethodModel;
        }
        return $output;
    }

    public static function Render() {
        global $post_id;
        $model = Serializer::getInstance()->denormalize(new \WC_Product($post_id),  ProductModel::class);
        $model = Serializer::getInstance()->normalize($model, "array");
        $shipments = self::get_shipping();
        $nonce = wp_create_nonce("product");


        ?><div
                id="pplcz_tab_overlay"
                class="panel woocommerce_options_panel"
                data-data='<?php echo esc_html(wp_json_encode(pplcz_normalize($model) )); ?>'
                data-methods='<?php echo esc_html(wp_json_encode( $shipments )); ?>'
                data-pplNonce='<?php echo esc_html(wp_json_encode($nonce)); ?>'
        >
        </div>
        <?php
        JsTemplate::add_inline_script("pplczInitProductTab", 'pplcz_tab_overlay');
    }

    public static function Save($post_id) {

        if (!isset($_POST['pplNonce']) || !wp_verify_nonce(sanitize_key($_POST['pplNonce']), 'product'))
        {
            return;
        }

        $model = new ProductModel();
        $pplDisabledParcelBox = false;
        $pplDisabledParcelShop = false;
        $pplDisabledAlzaBox = false;

        $pplConfirmAge15 = false;
        $pplConfirmAge18 = false;
        $pplDisabledTransport = [];

        if (isset($_POST['pplConfirmAge15']))
            $pplConfirmAge15 = sanitize_post(wp_unslash($_POST['pplConfirmAge15']), 'raw');
        if (isset($_POST['pplConfirmAge18']))
            $pplConfirmAge18 = sanitize_post(wp_unslash($_POST['pplConfirmAge18']), 'raw');
        if (isset($_POST['pplDisabledTransport']))
            $pplDisabledTransport = map_deep(wp_unslash($_POST['pplDisabledTransport']), 'sanitize_text_field');

        if (isset($_POST['pplDisabledParcelBox']))
            $pplDisabledParcelBox = sanitize_post(wp_unslash($_POST['pplDisabledParcelBox']), 'raw');

        if (isset($_POST['pplDisabledParcelShop']))
            $pplDisabledParcelShop = sanitize_post(wp_unslash($_POST['pplDisabledParcelShop']), 'raw');

        if (isset($_POST['pplDisabledAlzaBox']))
            $pplDisabledAlzaBox = sanitize_post(wp_unslash($_POST['pplDisabledAlzaBox']), 'raw');

        $names = array_map(function ($item) {
            if (preg_match('/pplSizes_(\d+)/', $item, $matches))
                return intval($matches[1]);
            return 0;
        }, array_filter(array_keys($_POST), function($v) {
           return strpos($v, 'pplSizes_') !== false;
        }));
        $maxCountSizes = 0;

        if ($names)
            $maxCountSizes = max($names);

        $packageSizes = [];

        for ($i = 0; $i <= $maxCountSizes; $i++) {
            $xSize = $ySize = $zSize = null;
            if (isset($_POST["pplSizes_{$i}_xSize"])) {
                $xSize = intval(sanitize_post(wp_unslash($_POST["pplSizes_{$i}_xSize"]), 'raw'));
                if ($xSize <= 0)
                    $xSize = null;
            }

            if (isset($_POST["pplSizes_{$i}_ySize"])) {
                $ySize = floatval(sanitize_post(wp_unslash($_POST["pplSizes_{$i}_ySize"]), 'raw'));
                if ($ySize <= 0)
                    $ySize = null;
            }

            if (isset($_POST["pplSizes_{$i}_zSize"])) {
                $zSize = floatval(sanitize_post(wp_unslash($_POST["pplSizes_{$i}_zSize"]), 'raw'));
                if ($zSize <= 0)
                    $zSize = null;
            }
            if ($xSize || $ySize || $zSize)
            {
                $packageSize = new PackageSizeModel();
                $packageSize->setXSize($xSize);
                $packageSize->setYSize($ySize);
                $packageSize->setZSize($zSize);
                $packageSizes[] = $packageSize;
            }
        }

        $model->setPplSizes($packageSizes);
        $model->setPplConfirmAge15(!!$pplConfirmAge15);
        $model->setPplConfirmAge18(!!$pplConfirmAge18);

        if (is_array($pplDisabledTransport)) {
            $model->setPplDisabledTransport($pplDisabledTransport);
        }
        $model->setPplDisabledParcelBox(!!$pplDisabledParcelBox);
        $model->setPplDisabledParcelShop(!!$pplDisabledParcelShop);
        $model->setPplDisabledAlzaBox($pplDisabledAlzaBox);

        $product = new \WC_Product($post_id);
        pplcz_denormalize($model, \WC_Product::class, [ "product" => $product]);
        pplcz_set_update_setting();
        $product->save_meta_data();
    }

    public static function register()
    {
        add_filter("woocommerce_product_data_tabs", array(Tab::class, "Tabs"));
        add_action("woocommerce_product_data_panels", array(Tab::class, "Render"));
        add_action("woocommerce_process_product_meta", array(Tab::class, "Save"));

    }
}

