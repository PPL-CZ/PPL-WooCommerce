<?php
defined("WPINC") or die();
?>
<div id="ppl_filter_table" class="alignleft actions">
    <button id="pplcz-create-shipments" class="button" style="display: none">Vytisknout zásilky</button>
    <a href="<?php echo esc_url($pplcz_newCollectionUrl); ?>" class="button">Nový svoz</a>
</div>


