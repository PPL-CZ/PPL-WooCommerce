# 1.0.11
- úprava filtrace metod dopravy
- oprava přepočtu při výběru jiné měny
# 1.0.12
- odstranění bank account
- opravy
# 1.0.13
- oprava problému s výběrem u mapy při změně země
- oprava chování naplánovaných akcí
- drobné opravy
# 1.0.14
- možnost určení výdejního místa u produktu a kategorie
# 1.0.15
- oprava stahování souboru v případě problému stahování souboru
# 1.0.16
- oprava příplatku na dobírku v případě různých měn a DPH
# 1.0.17
- oprava hlášky v rácmi chybějících nebo špatných údajů
# 1.0.18
- upravení chování košíku a pokladny v react komponentách
# 1.0.19
- v případě, že je doprava zdarma, je vypsáno "zdarma" u ppl dopravy
- změna názvu ident. údajů pro napojení na ppl.cz api
# 1.0.20
- přepočítávání dph, pokud je $shipment->is_taxable() (issue: 2);
- odstranění warningu (isset místo @) (issue: 5, 6, 7, 8)
# 1.0.21
- možnost ceny dopravy podle váhy
# 1.0.22
- možnost povolení/zakázání mapy v rámci dopravy či globálně
- možnost odeslání info o pluginu
# 1.0.23
- oprava uložení výdejního místa v novém košíku
# 1.0.24
- oprava inicializace pluginu
# 1.0.25
- úprava logování
# 1.0.26
- chybějící kontakt ve vytištěném labelu